#!/bin/zsh
# usage: samp.sh <verb>
S=${0:A:h}; B=$S/target/release/itsjustcad
$B --open $S/site.json --run $S/$1.script --headless > $S/out.samp.$1.txt 2>&1 &
P=$!; /usr/bin/sample $P 30 1 -mayDie -file $S/samp.$1.txt >/dev/null 2>&1; wait $P
